package com.bnd.bnd_lg360

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Build
import android.util.Log

class CameraNetworkManager(private val context: Context) {

    private val connectivityManager =
        context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

    private var networkCallback: ConnectivityManager.NetworkCallback? = null
    private var isBound = false

    fun bindToCameraWifi(onBoundSuccess: () -> Unit, onError: (String) -> Unit) {
        if (isBound) {
            onBoundSuccess()
            return
        }

        val request = NetworkRequest.Builder()
            .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
            .removeCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .build()

        networkCallback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                super.onAvailable(network)

                val capabilities = connectivityManager.getNetworkCapabilities(network)
                val isWifi = capabilities?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true

                if (isWifi) {
                    val success = connectivityManager.bindProcessToNetwork(network)
                    if (success) {
                        isBound = true
                        Log.d("BND_Network", "Uygulama başarıyla kamera Wi-Fi ağına bağlandı.")
                        onBoundSuccess()
                    } else {
                        onError("Ağ bağlantısı process'e kilitlenemedi.")
                    }
                }
            }

            override fun onLost(network: Network) {
                super.onLost(network)
                Log.d("BND_Network", "Kamera Wi-Fi bağlantısı koptu.")
                unbind()
            }

            override fun onUnavailable() {
                super.onUnavailable()
                onError("Kamera Wi-Fi ağı bulunamadı.")
            }
        }

        try {
            connectivityManager.requestNetwork(request, networkCallback!!)
        } catch (e: Exception) {
            onError("Ağ isteği hatası: ${e.localizedMessage}")
        }
    }

    fun unbind() {
        if (isBound) {
            connectivityManager.bindProcessToNetwork(null)
            isBound = false
        }
        networkCallback?.let {
            try {
                connectivityManager.unregisterNetworkCallback(it)
            } catch (e: Exception) {
                Log.e("BND_Network", "Callback sonlandırma hatası: ${e.message}")
            }
            networkCallback = null
        }
    }
}