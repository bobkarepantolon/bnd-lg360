# BND-LG360 (LG 360 Cam LGR105 Manager)
Paketlemeye hazır Flutter projesi.

Derlemek için:
```bash
flutter pub get
flutter build apk --release
```
