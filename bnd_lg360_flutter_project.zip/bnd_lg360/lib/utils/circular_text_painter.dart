import 'dart:math' as math;
import 'package:flutter/material.dart';

class CircularTextPainter extends CustomPainter {
  final String text;
  final double radiusRatio;
  final Color diskColor;
  final Color textColor;
  final Color borderColor;

  CircularTextPainter({
    required this.text,
    required this.radiusRatio,
    this.diskColor = const Color(0xFF101014),
    this.textColor = const Color(0xFFF5F5F7),
    this.borderColor = Colors.amber,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final double maxR = math.min(size.width, size.height) / 2 - 16;
    final double radius = maxR * (radiusRatio / 0.15).clamp(0.5, 1.0);

    final diskPaint = Paint()..color = diskColor..style = PaintingStyle.fill;
    canvas.drawCircle(center, radius, diskPaint);

    final borderPaint = Paint()..color = borderColor.withOpacity(0.8)..strokeWidth = 2.0..style = PaintingStyle.stroke;
    canvas.drawCircle(center, radius, borderPaint);

    if (text.trim().isEmpty) return;

    final double textRadius = radius * 0.72;
    final cleanText = text.trim();
    const double arcSpan = math.pi * 0.75;
    final double startAngle = (math.pi - arcSpan) / 2;
    final double angleStep = arcSpan / math.max(1, cleanText.length - 1);

    final textStyle = TextStyle(
      color: textColor,
      fontSize: (radius * 0.14).clamp(10.0, 16.0),
      fontWeight: FontWeight.w600,
      letterSpacing: 1.2,
    );

    for (int i = 0; i < cleanText.length; i++) {
      final char = cleanText[i];
      if (char == ' ') continue;

      final double angle = math.pi - (startAngle + (i * angleStep));
      final double charX = center.dx + textRadius * math.cos(angle);
      final double charY = center.dy - textRadius * math.sin(angle);

      final textSpan = TextSpan(text: char, style: textStyle);
      final textPainter = TextPainter(text: textSpan, textDirection: TextDirection.ltr)..layout();

      canvas.save();
      canvas.translate(charX, charY);
      canvas.rotate(-angle + (math.pi / 2));
      textPainter.paint(canvas, Offset(-textPainter.width / 2, -textPainter.height / 2));
      canvas.restore();
    }
  }

  @override
  bool shouldRepaint(covariant CircularTextPainter oldDelegate) => true;
}