import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';
import 'package:gal/gal.dart';
import 'package:image/image.dart' as img;
import 'package:path_provider/path_provider.dart';

class NadirStamperService {
  static Future<Uint8List> applyNadirStamp({
    required Uint8List inputBytes,
    String stampText = "bendelimiyim.com • BND 360",
    double radiusRatio = 0.12,
    img.Color? backgroundColor,
  }) async {
    final img.Image? original = img.decodeImage(inputBytes);
    if (original == null) throw Exception("Görsel çözümlenemedi.");

    final int width = original.width;
    final int height = original.height;
    final int centerX = width ~/ 2;
    final int centerY = height;
    final int radius = (height * radiusRatio).toInt();
    final bgColor = backgroundColor ?? img.ColorRgb8(12, 12, 12);

    for (int y = height - radius; y < height; y++) {
      final int dy = centerY - y;
      final int dxLimit = math.sqrt(math.max(0, radius * radius - dy * dy)).toInt();
      final int startX = math.max(0, centerX - dxLimit);
      final int endX = math.min(width - 1, centerX + dxLimit);
      for (int x = startX; x <= endX; x++) {
        original.setPixel(x, y, bgColor);
      }
    }

    if (stampText.trim().isNotEmpty) {
      _drawCurvedText(
        image: original,
        text: stampText.trim(),
        centerX: centerX,
        centerY: centerY,
        radius: (radius * 0.72).toInt(),
        textColor: img.ColorRgb8(240, 240, 240),
      );
    }

    return Uint8List.fromList(img.encodeJpg(original, quality: 95));
  }

  static void _drawCurvedText({
    required img.Image image,
    required String text,
    required int centerX,
    required int centerY,
    required int radius,
    required img.Color textColor,
  }) {
    final font = image.width > 3000 ? img.arial48 : img.arial24;
    const double arcSpan = math.pi * 0.65;
    final double startAngle = (math.pi - arcSpan) / 2;
    final double angleStep = arcSpan / math.max(1, text.length - 1);

    for (int i = 0; i < text.length; i++) {
      final String char = text[i];
      if (char == ' ') continue;

      final double angle = math.pi - (startAngle + (i * angleStep));
      final int charX = (centerX + radius * math.cos(angle)).toInt();
      final int charY = (centerY - radius * math.sin(angle)).toInt();

      final charImage = img.Image(width: font.lineHeight * 2, height: font.lineHeight * 2, numChannels: 4);
      charImage.clear(img.ColorRgba8(0, 0, 0, 0));
      img.drawString(charImage, char, font: font, x: font.lineHeight ~/ 2, y: font.lineHeight ~/ 4, color: textColor);

      final double rotationDegrees = (angle * 180 / math.pi) - 90;
      final rotatedChar = img.copyRotate(charImage, angle: rotationDegrees);

      img.compositeImage(image, rotatedChar, dstX: charX - (rotatedChar.width ~/ 2), dstY: charY - (rotatedChar.height ~/ 2));
    }
  }

  static Future<String> saveToPhoneGallery({required Uint8List bytes, required String originalFileName}) async {
    final hasAccess = await Gal.hasAccess();
    if (!hasAccess) {
      await Gal.requestAccess();
    }
    final tempDir = await getTemporaryDirectory();
    final stampedFileName = originalFileName.replaceAll(".jpg", "_BND360.jpg");
    final tempFilePath = "${tempDir.path}/$stampedFileName";
    final tempFile = File(tempFilePath);
    await tempFile.writeAsBytes(bytes);
    await Gal.putImage(tempFilePath, album: "BND360");
    return tempFilePath;
  }
}