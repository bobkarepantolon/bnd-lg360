import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'package:http/http.dart' as http;
import 'network_bridge_service.dart';

class MjpegStreamService {
  http.Client? _client;
  StreamSubscription<List<int>>? _subscription;
  final StreamController<Uint8List> _frameController = StreamController<Uint8List>.broadcast();

  Stream<Uint8List> get frameStream => _frameController.stream;
  bool _isRunning = false;
  bool get isRunning => _isRunning;

  static const int _soiFirst = 0xFF;
  static const int _soiSecond = 0xD8;
  static const int _eoiFirst = 0xFF;
  static const int _eoiSecond = 0xD9;

  Future<void> startStream({String baseUrl = "http://192.168.43.1"}) async {
    if (_isRunning) return;
    _isRunning = true;

    try {
      await NetworkBridgeService.lockToCameraNetwork();
      _client = http.Client();
      final uri = Uri.parse("$baseUrl/osc/commands/execute");
      final request = http.Request("POST", uri)
        ..headers.addAll({"Content-Type": "application/json; charset=utf-8", "X-XSRF-Protected": "1"})
        ..body = jsonEncode({"name": "camera.getLivePreview"});

      final response = await _client!.send(request);
      final List<int> buffer = [];

      _subscription = response.stream.listen((chunk) {
        buffer.addAll(chunk);
        while (true) {
          final startIndex = _findSequence(buffer, _soiFirst, _soiSecond);
          if (startIndex == -1) {
            if (buffer.length > 4096) buffer.removeRange(0, buffer.length - 2);
            break;
          }
          final endIndex = _findSequence(buffer, _eoiFirst, _eoiSecond, startIndex + 2);
          if (endIndex == -1) break;
          final frameBytes = Uint8List.fromList(buffer.sublist(startIndex, endIndex + 2));
          if (!_frameController.isClosed) _frameController.add(frameBytes);
          buffer.removeRange(0, endIndex + 2);
        }
      }, onError: (_) => stopStream(), onDone: () => stopStream(), cancelOnError: true);
    } catch (e) {
      stopStream();
      rethrow;
    }
  }

  int _findSequence(List<int> data, int b1, int b2, [int startIndex = 0]) {
    for (int i = startIndex; i < data.length - 1; i++) {
      if (data[i] == b1 && data[i + 1] == b2) return i;
    }
    return -1;
  }

  void stopStream() {
    _isRunning = false;
    _subscription?.cancel();
    _subscription = null;
    _client?.close();
    _client = null;
  }

  void dispose() {
    stopStream();
    _frameController.close();
  }
}