import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import '../models/camera_state.dart';
import '../models/media_file.dart';
import 'network_bridge_service.dart';

class OscApiService {
  static final OscApiService _instance = OscApiService._internal();
  factory OscApiService() => _instance;
  OscApiService._internal();

  final String baseUrl = "http://192.168.43.1";
  final Duration timeout = const Duration(seconds: 10);

  Map<String, String> get _headers => {
        "Content-Type": "application/json; charset=utf-8",
        "X-XSRF-Protected": "1",
      };

  Future<Map<String, dynamic>> checkConnection() async {
    await NetworkBridgeService.lockToCameraNetwork();
    final url = Uri.parse("$baseUrl/osc/info");
    final response = await http.post(url, headers: _headers, body: jsonEncode({})).timeout(timeout);
    if (response.statusCode == 200) {
      return jsonDecode(utf8.decode(response.bodyBytes));
    }
    throw HttpException("Kamera /osc/info yanıt vermedi: ${response.statusCode}");
  }

  Future<CameraState> getDeviceState() async {
    final info = await checkConnection();
    final stateUrl = Uri.parse("$baseUrl/osc/state");
    final response = await http.post(stateUrl, headers: _headers, body: jsonEncode({})).timeout(timeout);
    if (response.statusCode == 200) {
      final stateJson = jsonDecode(utf8.decode(response.bodyBytes));
      return CameraState.fromOscResponses(infoJson: info, stateJson: stateJson);
    }
    throw HttpException("Kamera /osc/state yanıt vermedi: ${response.statusCode}");
  }

  Future<String?> takePhoto() async {
    final url = Uri.parse("$baseUrl/osc/commands/execute");
    final response = await http.post(url, headers: _headers, body: jsonEncode({"name": "camera.takePicture"})).timeout(const Duration(seconds: 15));
    if (response.statusCode == 200) {
      final json = jsonDecode(utf8.decode(response.bodyBytes));
      if (json['state'] == "done") {
        return json['results']?['fileUrl'];
      }
      await Future.delayed(const Duration(seconds: 2));
      final files = await fetchMediaList(entryCount: 1);
      return files.isNotEmpty ? files.first.fileUrl : null;
    }
    throw HttpException("Fotoğraf çekilemedi: ${response.statusCode}");
  }

  Future<List<MediaFile>> fetchMediaList({int entryCount = 100}) async {
    final url = Uri.parse("$baseUrl/osc/commands/execute");
    final response = await http.post(url, headers: _headers, body: jsonEncode({
      "name": "camera.listFiles",
      "parameters": {"fileType": "all", "entryCount": entryCount, "maxThumbSize": 160, "_detail": true}
    })).timeout(timeout);

    if (response.statusCode == 200) {
      final json = jsonDecode(utf8.decode(response.bodyBytes));
      final entries = json['results']?['entries'] as List<dynamic>? ?? [];
      return entries.map((item) => MediaFile.fromOscJson(item)).toList();
    }
    throw HttpException("Medya listesi alınamadı: ${response.statusCode}");
  }

  Future<File> downloadFile({required String fileUrl, required String fileName, required void Function(double) onProgress}) async {
    final client = http.Client();
    try {
      final req = http.Request("GET", Uri.parse(fileUrl));
      final res = await client.send(req);
      final total = res.contentLength ?? 0;
      final tempDir = await getTemporaryDirectory();
      final file = File("${tempDir.path}/$fileName");
      final sink = file.openWrite();
      int received = 0;
      await for (final chunk in res.stream) {
        sink.add(chunk);
        received += chunk.length;
        if (total > 0) onProgress(received / total);
      }
      await sink.flush();
      await sink.close();
      onProgress(1.0);
      return file;
    } finally {
      client.close();
    }
  }

  Future<bool> deleteFile(String fileUrl) async {
    final url = Uri.parse("$baseUrl/osc/commands/execute");
    final res = await http.post(url, headers: _headers, body: jsonEncode({
      "name": "camera.delete",
      "parameters": {"fileUrls": [fileUrl]}
    })).timeout(timeout);
    return res.statusCode == 200;
  }
}